//
//  DetailViewController.swift
//  TVshows
//
//  Created by DanielT on 2017/3/21.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

//  View controller of displaying the infos of the TV shows on the first tab

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        mainImage.image = UIImage(named: detailTitle)
        sideImage1.image = UIImage(named: (detailTitle + "1"))
        sideImage2.image = UIImage(named: (detailTitle + "2"))
        des.text! = desDict[detailTitle]!
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    var detailTitle = ""
    

    @IBOutlet weak var des: UILabel!
    @IBOutlet weak var mainImage: UIImageView!
    @IBOutlet weak var sideImage1: UIImageView!
    @IBOutlet weak var sideImage2: UIImageView!
    
    var desDict: [String:String] = ["Iron Fist": "Danny Rand returns to New York City after being missing for years, trying to reconnect with his past and his family legacy. He fights against the criminal element corrupting his world around him with his incredible kung-fu mastery and ability to summon the awesome power of the fiery Iron Fist", "The Walking Dead": "Sheriff Deputy Rick Grimes wakes up from a coma, to learn the world is in ruins, and must lead a group of survivors to stay alive.", "Game of Thrones": "In the mythical continent of Westeros, several powerful families fight for control of the Seven Kingdoms. As conflict erupts in the kingdoms of men, an ancient enemy rises once again to threaten them all. Meanwhile, the last heirs of a recently usurped dynasty plot to take back their homeland from across the Narrow Sea.", "Legion": "Legion, based on the Marvel Comics by Chris Claremont and Bill Sienkiewicz, is the story of David Haller (Dan Stevens), a troubled young man who may be more than human. Diagnosed as ...", "13 Reasons Why": "Follows teenager Clay Jensen, in his quest to uncover the story behind his classmate and crush, Hannah, and her decision to end her life."]

}
