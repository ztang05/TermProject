//
//  DetailsViewController.swift
//  TVshows
//
//  Created by DanielT on 2017/3/29.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//


//  View controller of displaying the details of a TV show

import UIKit
import UserNotifications

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var showTitle: UILabel!
    @IBOutlet weak var timeGenre: UILabel!
    @IBOutlet weak var showDes: UILabel!
    @IBOutlet weak var showImage: UIImageView!
    @IBOutlet weak var epImage: UIImageView!
    @IBOutlet weak var epDes: UILabel!
    @IBOutlet weak var epTitle: UILabel!
    @IBOutlet weak var epDate: UILabel!
    @IBOutlet weak var whatNext: UILabel!
    
    //  remind me function
    @IBAction func remind(_ sender: Any) {
        // to see if the show is still running
        if self.Tvshows.status == "Running"
        {
        //  get the time of next episode
        let dateS = self.Tvshows.nextDate
        let timeS = self.Tvshows.time
        let dateString = dateS.components(separatedBy: "-")
        let year = Int(dateString[0])!
        let month = Int(dateString[1])!
        let day = Int(dateString[2])!
        let timeString = timeS.components(separatedBy: ":")
        let hour = Int(timeString[0])!
        let min = Int(timeString[1])!
        var dateComponents = DateComponents()
        dateComponents.day = day
        dateComponents.month = month
        dateComponents.year = year
        dateComponents.hour = hour
        dateComponents.minute = min
        
        let content = UNMutableNotificationContent()
        content.title = "A Reminder from What's Next?"
        content.subtitle = "\(self.Tvshows.title)"
        content.body = "S\(String(self.Tvshows.season))E\(String(self.Tvshows.number)): \"\(self.Tvshows.epName)\" is now on air!\nWatch it now at \(self.Tvshows.network)"
        content.badge = 1
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        let request = UNNotificationRequest(identifier: "xxx", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        let alert = UIAlertController(title: "Success!", message: "What's Next will remind when the show is on air.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
        self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Opps!", message: "\(self.Tvshows.title) was already ended.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    
    var Tvshows = TVshows()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.showTitle.text = "\(Tvshows.title) (\(Tvshows.year))"
        self.timeGenre.text = "\(Tvshows.runtime) | \(Tvshows.genre) |"
        self.showDes.text = Tvshows.showDescription
        self.showImage.image = Tvshows.showImage
        if Tvshows.status == "Running" && Tvshows.nextDate != "N/A"
        {
            self.epImage.image = Tvshows.epImage
            self.epDes.text = Tvshows.epDescription
            self.epTitle.text = Tvshows.epName
            self.epDate.text = "Avaliable on \(Tvshows.nextDate)"
        }
        else
        {
            self.whatNext.text = "What's previous?"
            searchPrev(title: Tvshows.title)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //  function of searching the previous episode's info
    func searchPrev (title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://api.tvmaze.com/singlesearch/shows?q=\(movie)&embed=previousepisode")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
                            DispatchQueue.main.async
                                {
                                    
                                    if let embedded = jsonResult["_embedded"] as? [String: Any]
                                    {
                                        
                                        if let prevEpisode = embedded["previousepisode"] as? [String: Any]
                                        {
                                            
                                            if let airDate = prevEpisode["airdate"] as? String
                                            {
                                                self.epDate.text = "Last avaliable on \(airDate)"
                                            }
                                            if let epNamex = prevEpisode["name"] as? String
                                            {
                                                self.epTitle.text = epNamex
                                            }
                                            /*if let seasonx = nextEpisode["season"] as? Int
                                            {
                                                self.Tvshows.season = seasonx
                                            }
                                            if let numberx = nextEpisode["number"] as? Int
                                            {
                                                self.Tvshows.number = numberx
                                            }*/
                                            if let des = prevEpisode["summary"] as? String
                                            {
                                                let str = des.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                                self.epDes.text = str
                                            }
                                            /*if let airTime = nextEpisode["airtime"] as? String
                                            {
                                                self.Tvshows.time = airTime
                                            }*/
                                            if let images = prevEpisode["image"] as? [String: String]
                                            {
                                                if let imageExists = images["medium"]
                                                {
                                                    
                                                    let imageURL = URL(string: imageExists)
                                                    
                                                    if let imageData = try? Data(contentsOf: imageURL!)
                                                    {
                                                        self.epImage.image = UIImage(data: imageData)!
                                                    }
                                                    else
                                                    {
                                                        self.epImage.image = #imageLiteral(resourceName: "imageNA")
                                                    }
                                                }
                                                else
                                                {
                                                    self.epImage.image = #imageLiteral(resourceName: "imageNA")
                                                }
                                                
                                                
                                            }
                                            else
                                            {
                                                self.epImage.image = #imageLiteral(resourceName: "imageNA")
                                            }
                                        }
                                    }
                                    
                                    
                                    
                            }
                            
                            
                        }
                        catch {
                            
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
        
    }

}
