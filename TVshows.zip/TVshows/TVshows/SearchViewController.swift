//
//  SearchViewController.swift
//  tvShows
//
//  Created by DanielT on 2017/3/20.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

//  View controller of the search page

import UIKit

class SearchViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //  if the show is already in the favorite list
        
        for x in favoriteList {
            if x.title == input {
                like.setImage(#imageLiteral(resourceName: "liked-1"), for: .normal)
            }
        }
        
        //  search the show
        searchForTVshows(title: input)
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     @IBOutlet weak var nextEP: UILabel!
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var actor: UILabel!
    @IBOutlet weak var year: UILabel!
    @IBOutlet weak var nextEp: UILabel!
    @IBOutlet weak var like: UIButton!
    
    
    // add the show to favorite list or remove it
    
    @IBAction func add(_ sender: UIButton) {
        var checked = true
        for x in favoriteList {
            if x.title == input {
                checked = false
            }
        }
        if checked {
            searchInfo(title: input)
            favoriteList.append(Tvshows)
    
            
            sender.setImage(#imageLiteral(resourceName: "liked-1"), for: .normal)
            let alert = UIAlertController(title: "Success!", message: "You've added the TV show in your favorites", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            favoriteList = favoriteList.filter() {$0.title != input}
            let alert = UIAlertController(title: "Success!", message: "You've removed the TV show in your favorites", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
            sender.setImage(#imageLiteral(resourceName: "heart-outline-19"), for: .normal)
        }

    }
    
    
    
    var input = ""
    
    var Tvshows = TVshows()
    
    
    //  function of searching TV shows's info
    func searchForTVshows(title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://www.omdbapi.com/?t=\(movie)&type=series")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String,String>
                            
                            DispatchQueue.main.async
                                {
                                    if let titles = jsonResult["Title"]
                                    {
                                        self.Tvshows.title = titles
                                        self.name.text = "Title: \(titles)"
                                    }

                                    if let years = jsonResult["Year"]
                                    {
                                        self.year.text = "Year: \(years)"
                                        self.Tvshows.year = years
                                    }
                                    if let actors = jsonResult["Actors"]
                                    {
                                        self.actor.text = "Actors: \(actors)"
                                    }
                                    if let desc = jsonResult["Plot"]
                                    {
                                        self.Tvshows.showDescription = desc
                                    }
                                    if let gen = jsonResult["Genre"]
                                    {
                                        self.Tvshows.genre = gen
                                    }
                                    if let runT = jsonResult["Runtime"]
                                    {
                                        self.Tvshows.runtime = runT
                                    }
                                    if let rates = jsonResult["imdbRating"]
                                    {
                                        self.Tvshows.rating = rates
                                    }
                                   
                                    
                                    
                                    if let imageExists = jsonResult["Poster"]
                                    {
                                        
                                        let imageURL = URL(string: imageExists)
                                        
                                        if let imageData = try? Data(contentsOf: imageURL!)
                                        {
                                            self.imageView.image = UIImage(data: imageData)
                                            self.Tvshows.showImage = UIImage(data: imageData)!
                                        }
                                    }
                                    else{
                                        self.imageView.image = #imageLiteral(resourceName: "imageNA")
                                        self.Tvshows.showImage = #imageLiteral(resourceName: "imageNA")
                                    }
                                    if jsonResult["Type"] == "series"
                                    {
                                        
                                        
                                        self.getAirDate(title: title)
                                        
                                        
                                    }
                            }
                        }
                        catch {
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
    }

    
    //  function of searching TV shows' air dates
    func getAirDate(title: String)
    {
        
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://api.tvmaze.com/singlesearch/shows?q=\(movie)&embed=nextepisode")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
                            
                            DispatchQueue.main.async
                                {
                                    
                                    if let embedded = jsonResult["_embedded"] as? [String: Any]
                                    {
                                        
                                        if let nextEpisode = embedded["nextepisode"] as? [String: Any]
                                        {
                                            
                                            if let airDate = nextEpisode["airdate"] as? String
                                            {
                                                
                                                self.nextEp.text = "Next Episode: \(airDate)"
                                                
                                            }
                                        }
                                    }
                                    else
                                    {
                                        self.nextEp.text = "Ended"
                                    }
                                    
                            }
                            
                            
                        }
                        catch {
                            
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
     
     
    }
    
    //  function of searching TV shows' info
    func searchInfo(title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://api.tvmaze.com/singlesearch/shows?q=\(movie)&embed=nextepisode")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
                            DispatchQueue.main.async
                                {
                                    
                                    /*if let genres = jsonResult["genres"] as? [String]
                                    {
                                        self.Tvshows.genre  = genres
                                    }*/
                                    if let networkx = jsonResult["network"] as? [String: Any]
                                    {
                                        if let networkname = networkx["name"] as? String
                                        {
                                             self.Tvshows.network = networkname
                                        }
                                        if let timezonex = networkx["country"] as? [String: String]
                                        {
                                             self.Tvshows.timeZone = timezonex["timezone"]!
                                        }
                                    }
                                    if let statusx = jsonResult["status"] as? String
                                    {
                                        self.Tvshows.status = statusx
                                    }
                                    if let sch = jsonResult["schedule"] as? [String: Any]
                                    {
                                        if let days = sch["days"] as? [String]
                                        {
                                            self.Tvshows.day = days
                                        }
                                    }
                                    /*if let imagex = jsonResult["image"] as? [String: String]
                                    {
                                        if let imageExists = imagex["medium"]
                                        {
                                            
                                            let imageURL = URL(string: imageExists)
                                            
                                            if let imageData = try? Data(contentsOf: imageURL!)
                                            {
                                                self.Tvshows.showImage = UIImage(data: imageData)!
                                            }
                                        }
                                        
                                    }*/
                                    
                                    //if let summary = jsonResult["summary"] as? String
                                   // {
                                    //  _tr = summary.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                        //self.Tvshows.showDescription = str
                                        
                                   // }
                                    if let embedded = jsonResult["_embedded"] as? [String: Any]
                                    {
                                        
                                        if let nextEpisode = embedded["nextepisode"] as? [String: Any]
                                        {
                                            
                                            if let airDate = nextEpisode["airdate"] as? String
                                            {
                                                 self.Tvshows.nextDate = airDate
                                            }
                                            else
                                            {
                                                self.Tvshows.nextDate = "N/A"
                                            }
                                            if let epNamex = nextEpisode["name"] as? String
                                            {
                                                  self.Tvshows.epName = epNamex
                                            }
                                            if let seasonx = nextEpisode["season"] as? Int
                                            {
                                                self.Tvshows.season = seasonx
                                            }
                                            if let numberx = nextEpisode["number"] as? Int
                                            {
                                                 self.Tvshows.number = numberx
                                            }
                                            if let des = nextEpisode["summary"] as? String
                                            {
                                                let str = des.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                                self.Tvshows.epDescription = str
                                            }
                                            else
                                            {
                                                self.Tvshows.epDescription = "Episode Description is currently unavailable."
                                            }
                                            if let airTime = nextEpisode["airtime"] as? String
                                            {
                                                 self.Tvshows.time = airTime
                                            }
                                            if let images = nextEpisode["image"] as? [String: String]
                                            {
                                                if let imageExists = images["medium"]
                                                {
                                                    
                                                    let imageURL = URL(string: imageExists)
                                                    
                                                    if let imageData = try? Data(contentsOf: imageURL!)
                                                    {
                                                         self.Tvshows.epImage = UIImage(data: imageData)!
                                                    }
                                                    else
                                                    {
                                                        self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                                    }
                                                }
                                                else
                                                {
                                                    self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                                }
                                                

                                            }
                                            else
                                            {
                                                self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                            }
                                        }
                                        else
                                        {
                                            self.Tvshows.epName = "N/A"
                                            self.Tvshows.season = 0
                                            self.Tvshows.number  = 0
                                            self.Tvshows.nextDate = "N/A"
                                            self.Tvshows.epDescription = "N/A"
                                            self.Tvshows.time  = "N/A"
                                        }
                                    }
                                    else
                                    {
                                        self.Tvshows.epName = "N/A"
                                        self.Tvshows.season = 0
                                        self.Tvshows.number  = 0
                                        self.Tvshows.nextDate = "N/A"
                                        self.Tvshows.epDescription = "N/A"
                                        self.Tvshows.time  = "N/A"
                                    }
                                    
                                    
                            }
                            
                            
                        }
                        catch {
                            
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
        
        
        
        
        
        
    }

    
    
    
}
