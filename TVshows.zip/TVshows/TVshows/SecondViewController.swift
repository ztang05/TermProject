//
//  SecondViewController.swift
//  TVshows
//
//  Created by DanielT on 2017/3/21.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

//  View controller of second tab

import UIKit

var favoriteList: [TVshows] = []

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (favoriteList.count)
    }
    
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FavoriteTableViewCell
        //cell.myImage.image = UIImage(named:favoriteList[indexPath.row])
        cell.nextDate.text = "Next episode: \(favoriteList[indexPath.row].nextDate)"
        cell.epImage.image = favoriteList[indexPath.row].showImage
        cell.showDes.text = favoriteList[indexPath.row].showDescription
        cell.rating.text = "\(favoriteList[indexPath.row].rating)/10"
        cell.star.image = #imageLiteral(resourceName: "star")
        cell.showsTitle.text = (favoriteList[indexPath.row].title)
        return (cell)
    }
    var Tvshows = TVshows()
    
    // After a row has the minus or plus button invoked (based on the UITableViewCellEditingStyle for the cell), the dataSource must commit the change
    // Not called for edit actions using UITableViewRowAction - the action's handler will be invoked instead
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            favoriteList.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toEp" {
            
            let destinationVC = segue.destination as! DetailsViewController
            destinationVC.Tvshows = Tvshows
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Tvshows = favoriteList[indexPath.row]
        // Segue to the Detail view controller
        self.performSegue(withIdentifier: "toEp", sender: self)
    }

    
    
    //**************************************************
/*    func searchInfo(title: String)
    {

        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://api.tvmaze.com/singlesearch/shows?q=\(movie)&embed=nextepisode")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
                            DispatchQueue.main.async
                                {
                                    
                                    if let networkx = jsonResult["network"] as? [String: Any]
                                    {
                                        if let networkname = networkx["name"] as? String
                                        {
                                            self.Tvshows.network = networkname
                                        }
                                        if let timezonex = networkx["country"] as? [String: String]
                                        {
                                            self.Tvshows.timeZone = timezonex["timezone"]!
                                        }
                                    }
                                    if let statusx = jsonResult["status"] as? String
                                    {
                                        self.Tvshows.status = statusx
                                    }
                                    if let embedded = jsonResult["_embedded"] as? [String: Any]
                                    {
                                        
                                        if let nextEpisode = embedded["nextepisode"] as? [String: Any]
                                        {
                                            
                                            if let airDate = nextEpisode["airdate"] as? String
                                            {
                                                self.Tvshows.nextDate = airDate
                                            }
                                            else
                                            {
                                                self.Tvshows.nextDate = "N/A"
                                            }
                                            if let epNamex = nextEpisode["name"] as? String
                                            {
                                                self.Tvshows.epName = epNamex
                                            }
                                            if let seasonx = nextEpisode["season"] as? Int
                                            {
                                                self.Tvshows.season = seasonx
                                            }
                                            if let numberx = nextEpisode["number"] as? Int
                                            {
                                                self.Tvshows.number = numberx
                                            }
                                            if let des = nextEpisode["summary"] as? String
                                            {
                                                let str = des.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                                self.Tvshows.epDescription = str
                                            }
                                            else
                                            {
                                                self.Tvshows.epDescription = "Episode Description is currently unavailable."
                                            }
                                            if let airTime = nextEpisode["airtime"] as? String
                                            {
                                                self.Tvshows.time = airTime
                                            }
                                            if let images = nextEpisode["image"] as? [String: String]
                                            {
                                                if let imageExists = images["medium"]
                                                {
                                                    
                                                    let imageURL = URL(string: imageExists)
                                                    
                                                    if let imageData = try? Data(contentsOf: imageURL!)
                                                    {
                                                        self.Tvshows.epImage = UIImage(data: imageData)!
                                                    }
                                                    else
                                                    {
                                                        self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                                    }
                                                }
                                                else
                                                {
                                                    self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                                }
                                                
                                                
                                            }
                                            else
                                            {
                                                self.Tvshows.epImage = #imageLiteral(resourceName: "imageNA")
                                            }
                                        }
                                        else
                                        {
                                            self.Tvshows.epName = "N/A"
                                            self.Tvshows.season = 0
                                            self.Tvshows.number  = 0
                                            self.Tvshows.nextDate = "N/A"
                                            self.Tvshows.epDescription = "N/A"
                                            self.Tvshows.time  = "N/A"
                                        }
                                    }
                                    else
                                    {
                                        self.Tvshows.epName = "N/A"
                                        self.Tvshows.season = 0
                                        self.Tvshows.number  = 0
                                        self.Tvshows.nextDate = "N/A"
                                        self.Tvshows.epDescription = "N/A"
                                        self.Tvshows.time  = "N/A"
                                    }
                                    
                                    
                            }
                            
                            
                        }
                        catch {
                            
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
        
        
    }
    

    
    func searchForTVshows(title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://www.omdbapi.com/?t=\(movie)&type=series")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String,String>
                            
                            DispatchQueue.main.async
                                {
                                    if let titles = jsonResult["Title"]
                                    {
                                        self.Tvshows.title = titles
                                    }
                            
                                    if let years = jsonResult["Year"]
                                    {
                                        self.Tvshows.year = years
                                    }
                                    if let desc = jsonResult["Plot"]
                                    {
                                        self.Tvshows.showDescription = desc
                                    }
                                    if let gen = jsonResult["Genre"]
                                    {
                                        self.Tvshows.genre = gen
                                    }
                                    if let runT = jsonResult["Runtime"]
                                    {
                                        self.Tvshows.runtime = runT
                                    }
                                    if let rates = jsonResult["imdbRating"]
                                    {
                                        self.Tvshows.rating = rates
                                    }
                                    
                                    
                                    
                                    if let imageExists = jsonResult["Poster"]
                                    {
                                        
                                        let imageURL = URL(string: imageExists)
                                        
                                        if let imageData = try? Data(contentsOf: imageURL!)
                                        {
                                            self.Tvshows.showImage = UIImage(data: imageData)!
                                        }
                                    }
                                    else{
                                        self.Tvshows.showImage = #imageLiteral(resourceName: "imageNA")
                                    }
                                    
                            }
                        }
                        catch {
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
    }
 */

}
