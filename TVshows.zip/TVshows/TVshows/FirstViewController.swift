//
//  FirstViewController.swift
//  TVshows
//
//  Created by DanielT on 2017/3/20.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

//  View controller of first tab

import UIKit
import UserNotifications

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {

    var recommendList = ["Iron Fist","The Walking Dead", "Game of Thrones", "Legion", "13 Reasons Why"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //recommendList = (UserDefaults.standard.object(forKey: "recommendList") as? [String])!
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler: {didAllow, error in})
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(FirstViewController.dismissKeyboard))        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var recommend: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    //var check = true
    
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (recommendList.count)
    }
    
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! HomeTableViewCell
        cell.myImage.image = UIImage(named:recommendList[indexPath.row])
        cell.label.text = recommendList[indexPath.row]
        return (cell)
    }
    

    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    var input = ""
    var detailTitle = ""
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toSearch" {
            
            let destinationVC = segue.destination as! SearchViewController
            destinationVC.input = input
            
        }
        
        if segue.identifier == "toDetail" {
            
            let destinationVC = segue.destination as! DetailViewController
            destinationVC.detailTitle = detailTitle
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        detailTitle = recommendList[indexPath.row]
        // Segue to the Detail view controller
        self.performSegue(withIdentifier: "toDetail", sender: self)
    }
    
    
    @available(iOS 2.0, *)
    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar) // called when keyboard search button pressed
    {
        input = searchBar.text!
        performSegue(withIdentifier: "toSearch", sender: self)
    }
    
    


}

