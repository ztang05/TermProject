//
//  NextViewController.swift
//  TVshows
//
//  Created by DanielT on 4/4/17.
//  Copyright © 2017 Zhewen Tang. All rights reserved.
//


//  View controller of displaying the info of the recommended show

var mightList = [TVshows]()


import UIKit

class NextViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        searchForTVshows(title: input)
        searchInfo(title: input)
        
        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    // Section of outlets
    @IBOutlet weak var titleX: UILabel!
    @IBOutlet weak var imageX: UIImageView!
    @IBOutlet weak var yearX: UILabel!
    @IBOutlet weak var nextX: UILabel!
    @IBOutlet weak var likeX: UIButton!
    
    //  add the show or remove the show
    @IBAction func addX(_ sender: UIButton) {
        var checked = true
        for x in favoriteList {
            if self.titleX.text == x.title {
                checked = false
            }
        }
        if checked {
            favoriteList.append(sample)
            sender.setImage(#imageLiteral(resourceName: "liked-1"), for: .normal)
            let alert = UIAlertController(title: "Success!", message: "You've added the TV show in your favorites", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
            
        }
        else {
            favoriteList = favoriteList.filter() {$0.title != self.titleX.text}
            
            let alert = UIAlertController(title: "Success!", message: "You've removed the TV show in your favorites", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
            sender.setImage(#imageLiteral(resourceName: "heart-outline-19"), for: .normal)
        }

    }
    
    @IBOutlet weak var actorX: UILabel!
    var input = ""
    var sample = TVshows()
    
    
    //Other helper functions
    //**************************************
    //1.
    
    func searchForTVshows(title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://www.omdbapi.com/?t=\(movie)&type=series")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
                            
                            DispatchQueue.main.async
                                {
                                    if let titles = jsonResult["Title"] as? String
                                    {
                                        self.sample.title = titles
                                        self.titleX.text = "Title: \(titles)"
                                    }
                                    if let years = jsonResult["Year"] as? String
                                    {
                                        self.sample.year = years
                                    }
                                    if let actors = jsonResult["Actors"] as? String
                                    {
                                        self.actorX.text = "Actors: \(actors)"
                                    }
                                    if let desc = jsonResult["Plot"] as? String
                                    {
                                        self.sample.showDescription = desc
                                    }
                                    if let gen = jsonResult["Genre"] as? String
                                    {
                                        self.sample.genre = gen
                                        self.nextX.text = gen
                                    }
                                    if let runT = jsonResult["Runtime"] as? String
                                    {
                                        self.sample.runtime = runT
                                    }
                                    if let rates = jsonResult["imdbRating"] as? String
                                    {
                                        self.sample.rating = rates
                                    }
                                    
                                    
                                    
                                    if let imageExists = jsonResult["Poster"] as? String
                                    {
                                        
                                        let imageURL = URL(string: imageExists)
                                        
                                        if let imageData = try? Data(contentsOf: imageURL!)
                                        {
                                            self.imageX.image = UIImage(data: imageData)
                                            self.sample.showImage = UIImage(data: imageData)!
                                        }
                                    }
                                    else{
                                        self.imageX.image = #imageLiteral(resourceName: "imageNA")
                                        self.sample.showImage = #imageLiteral(resourceName: "imageNA")
                                    }
                                                                }
                        }
                        catch {
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
    }
    
    //2.
    func searchInfo(title: String)
    {
        if let movie = title.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        {
            
            let url = URL(string: "http://api.tvmaze.com/singlesearch/shows?q=\(movie)&embed=nextepisode")
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: { (data, response, error) in
                
                
                if error != nil
                {
                    let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil)
                }
                else
                {
                    
                    if data != nil
                    {
                        
                        do
                        {
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
                            DispatchQueue.main.async
                                {
                                    if let networkx = jsonResult["network"] as? [String: Any]
                                    {
                                        if let networkname = networkx["name"] as? String
                                        {
                                            self.sample.network = networkname
                                        }
                                        if let timezonex = networkx["country"] as? [String: String]
                                        {
                                            self.sample.timeZone = timezonex["timezone"]!
                                        }
                                    }
                                    if let statusx = jsonResult["status"] as? String
                                    {
                                        self.sample.status = statusx
                                    }
                                    if let sch = jsonResult["schedule"] as? [String: Any]
                                    {
                                        if let days = sch["days"] as? [String]
                                        {
                                            self.sample.day = days
                                            self.yearX.text = "Days: \(days[0])"
                                        }
                                    }
                                    if let embedded = jsonResult["_embedded"] as? [String: Any]
                                    {
                                        
                                        if let nextEpisode = embedded["nextepisode"] as? [String: Any]
                                        {
                                            
                                            if let airDate = nextEpisode["airdate"] as? String
                                            {
                                                self.sample.nextDate = airDate
                                                //self.nextX.text = airDate
                                            }
                                            else
                                            {
                                                self.sample.nextDate = "N/A"
                                                self.nextX.text = "N/A"
                                            }
                                            if let epNamex = nextEpisode["name"] as? String
                                            {
                                                self.sample.epName = epNamex
                                            }
                                            if let seasonx = nextEpisode["season"] as? Int
                                            {
                                                self.sample.season = seasonx
                                            }
                                            if let numberx = nextEpisode["number"] as? Int
                                            {
                                                self.sample.number = numberx
                                            }
                                            if let des = nextEpisode["summary"] as? String
                                            {
                                                let str = des.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                                self.sample.epDescription = str
                                            }
                                            else
                                            {
                                                self.sample.epDescription = "Episode Description is currently unavailable."
                                            }
                                            if let airTime = nextEpisode["airtime"] as? String
                                            {
                                                self.sample.time = airTime
                                            }
                                            if let images = nextEpisode["image"] as? [String: String]
                                            {
                                                if let imageExists = images["medium"]
                                                {
                                                    
                                                    let imageURL = URL(string: imageExists)
                                                    
                                                    if let imageData = try? Data(contentsOf: imageURL!)
                                                    {
                                                        self.sample.epImage = UIImage(data: imageData)!
                                                    }
                                                    else
                                                    {
                                                        self.sample.epImage = #imageLiteral(resourceName: "imageNA")
                                                    }
                                                }
                                                else
                                                {
                                                    self.sample.epImage = #imageLiteral(resourceName: "imageNA")
                                                }
                                                
                                                
                                            }
                                            else
                                            {
                                                self.sample.epImage = #imageLiteral(resourceName: "imageNA")
                                            }
                                        }
                                        else
                                        {
                                            self.sample.epName = "N/A"
                                            self.sample.season = 0
                                            self.sample.number  = 0
                                            self.sample.nextDate = "N/A"
                                            self.sample.epDescription = "N/A"
                                            self.sample.time  = "N/A"
                                        }
                                    }
                                    else
                                    {
                                        self.sample.epName = "N/A"
                                        self.sample.season = 0
                                        self.sample.number  = 0
                                        self.sample.nextDate = "N/A"
                                        self.sample.epDescription = "N/A"
                                        self.sample.time  = "N/A"
                                    }
                                    
                                    
                            }
                            
                            
                        }
                        catch {
                            
                            
                        }
                    }
                }
            })
            
            task.resume()
            
        }
        
        
        
        
        
        
    }


    
    
    
    
}
