//
//  TVshows.swift
//  Created by DanielT on 2017/3/27.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

//  class of TVshows
//  Help create an object to store useful infomation of a TV show


import Foundation
import UIKit

class TVshows {
    var title = ""
    var epName = ""
    var season = 0
    var number = 0
    var nextDate = ""
    var showDescription = ""
    var epDescription = ""
    var showImage = UIImage()
    var epImage = UIImage()
    var genre = ""
    var time = ""
    var network = ""
    var timeZone = ""
    var rating = ""
    var year = ""
    var runtime = ""
    var status = ""
    var day = ["Nothing", "here"]
    
}
