//
//  ShakeViewController.swift
//  TVshows
//
//  Created by DanielT on 4/7/17.
//  Copyright © 2017 Zhewen Tang. All rights reserved.
//

var genres = [String]()
import UIKit

class ShakeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var subView: UIView!
    
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if event?.subtype == UIEventSubtype.motionShake
        {

            if !genres.isEmpty
            {
                input = recommendX(list: recommendItem, list2: genres)
                self.performSegue(withIdentifier: "toShow", sender: self)
            }
        }
    }

    
    var input = ""
    
    
    @IBAction func crime(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Crime" }
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Crime")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    
    @IBAction func drama(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Drama"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Drama")
            sender.setTitleColor(UIColor.red, for: .normal)
        }

    }
    
    @IBAction func animation(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Animation"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Animation")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func romance(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Romance"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Romance")
            sender.setTitleColor(UIColor.red, for: .normal)
        }

    }
    
    @IBAction func horror(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Horror"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Horror")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func mystery(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Mystery"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Mystery")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func thriller(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Thriller"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Thriller")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func adventure(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Adventure"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Adventure")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func action(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Action"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Action")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func fantasy(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Fantasy"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Fantasy")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    @IBAction func scifi(_ sender: UIButton) {
        if sender.currentTitleColor != UIColor.blue
        {
            genres = genres.filter { $0 != "Sci-Fi"}
            sender.setTitleColor(UIColor.blue, for: .normal)
        }
        else
        {
            genres.append("Sci-Fi")
            sender.setTitleColor(UIColor.red, for: .normal)
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func recommendX(list: [TVshows], list2: [String]) -> String
    {
        let gList = list2
        
        let resultSet = Set(gList)
        
        
        // Section of compute recommendations
        // **********************************
        var xList = [String]()
        var yList = [Int]()
        for x in list
        {
            if resultSet.intersection(x.genre.components(separatedBy: ", ")).count > 0
            {
                xList.append(x.title)
                yList.append(resultSet.intersection(x.genre.components(separatedBy: ", ")).count)
            }
        }
        let sortedxy = zip(xList, yList).sorted { $0.1 > $1.1 }
        
        xList = sortedxy.map { $0.0 }
        yList = sortedxy.map { $0.1 }
        
        print("**********************")
        for (x,y) in zip(xList, yList)
        {
            print ("Show \(x) has \(y) intersections")
        }
        var favListTitle = [String]()
        for x in favoriteList
        {
            favListTitle.append(x.title)
        }
        var firstList = [String]()
        var secondList = [String]()
        var lastList = [String]()
        
        for (x,y) in zip(xList, yList)
        {
            if y == 3
            {
                firstList.append(x)
            }
            if y == 2
            {
                secondList.append(x)
            }
            if y == 1
            {
                lastList.append(x)
            }
        }
        
        if !firstList.isEmpty
        {
            for x in favListTitle
            {
                firstList = firstList.filter { $0 != x }
            }
            if firstList.isEmpty
            {
                return recommendX(list: list, list2: list2)
            }
            let index = Int(arc4random_uniform(UInt32(firstList.count)))
            return firstList[index]
        }
        else
        {
            if !secondList.isEmpty
            {
                for x in favListTitle
                {
                    secondList = secondList.filter { $0 != x }
                }
                if secondList.isEmpty
                {
                    return recommendX(list: list, list2: list2)
                }
                let index = Int(arc4random_uniform(UInt32(secondList.count)))
                return secondList[index]
            }
            else
            {
                if !lastList.isEmpty
                {
                    for x in favListTitle
                    {
                        lastList = lastList.filter { $0 != x }
                    }
                    if lastList.isEmpty
                    {
                        return recommendX(list: list, list2: list2)
                    }
                    let index = Int(arc4random_uniform(UInt32(lastList.count)))
                    return lastList[index]
                }
                else
                {
                    return "Nothing found"
                }
            }
        }
        
        //End
        //**********************************
        
    }




}
