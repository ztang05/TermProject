//
//  ShakesViewController.swift
//  TVshows
//
//  Created by DanielT on 4/8/17.
//  Copyright © 2017 Zhewen Tang. All rights reserved.
//

//  View controller of third tab

import UIKit
var recommendItem = [TVshows]()

class ShakesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // data files
        
        let item1  = TVshows()
        item1.title = "Band of Brothers"
        item1.genre = "Action, Drama, History"
        item1.day = ["Sunday"]
        
        let item2 = TVshows()
        item2.title = "Game of Thrones"
        item2.genre = "Adventure, Drama, Fantasy"
        item2.day = ["Sunday"]
        
        let item3 = TVshows()
        item3.title = "Breaking Bad"
        item3.genre = "Crime, Drama, Thriller"
        item3.day = ["Sunday"]
        
        
        let item4 = TVshows()
        item4.title = "Stranger Things"
        item4.genre = "Drama, Fantasy, Horror"
        item4.day = ["Friday"]
        
        
        let item5 = TVshows()
        item5.title = "House of Cards"
        item5.genre = "Drama"
        item5.day = ["Tuesday"]
        
        let item6 = TVshows()
        item6.title = "Rick and Morty"
        item6.genre = "Animation, Adventure, Comedy"
        item6.day = ["Saturday"]
        
        let item7 = TVshows()
        item7.title = "Sherlock"
        item7.genre = "Crime, Drama, Mystery"
        item7.day = ["Sunday"]
        
        let item8 = TVshows()
        item8.title = "True Detective"
        item8.genre = "Crime, Drama, Mystery"
        item8.day = ["Sunday"]
        
        let item9 = TVshows()
        item9.title = "Westworld"
        item9.genre = "Drama, Mystery, Sci-Fi"
        item9.day = ["Sunday"]
        
        let item10 = TVshows()
        item10.title = "Narcos"
        item10.genre = "Biography, Crime, Drama"
        item10.day = ["Friday"]
        
        let item11 = TVshows()
        item11.title = "Friends"
        item11.genre = "Comedy, Romance"
        item11.day = ["Thursday"]
        
        let item12 = TVshows()
        item12.title = "Black Mirror"
        item12.genre = "Drama, Sci-Fi, Thriller"
        item12.day = ["Friday"]
        
        let item13 = TVshows()
        item13.title = "Dexter"
        item13.genre = "Crime, Drama, Mystery"
        item13.day = ["Sunday"]
        
        let item14 = TVshows()
        item14.title = "Prison Break"
        item14.genre = "Action, Crime, Drama"
        item14.day = ["Tuesday"]
        
        let item15 = TVshows()
        item15.title = "Lost"
        item15.genre = "Adventure, Drama, Fantasy"
        item15.day = ["Tuesday"]
        
        let item16 = TVshows()
        item16.title = "The Simpsons"
        item16.genre = "Animation, Comedy"
        item16.day = ["Sunday"]
        
        let item17 = TVshows()
        item17.title = "Hannibal"
        item17.genre = "Crime, Drama, Horror"
        item17.day = ["Thursday"]
        
        let item18 = TVshows()
        item18.title = "Doctor Who"
        item18.genre = "Adventure, Drama, Family"
        item18.day = ["Saturday"]
        
        let item19 = TVshows()
        item19.title = "Person of Interest"
        item19.genre = "Action, Crime, Drama"
        item19.day = ["Tuesday"]
        
        let item20 = TVshows()
        item20.title = "Shameless"
        item20.genre = "Comedy, Drama"
        item20.day = ["Sunday"]
        
        let item21 = TVshows()
        item21.title = "Prison Break: Sequel"
        item21.genre = "Action, Crime, Drama"
        item21.day = ["Tuesday"]
        
        let item22 = TVshows()
        item22.title = "13 Reasons Why"
        item22.genre = "Drama, Mystery"
        item22.day = ["Friday"]
        
        let item23 = TVshows()
        item23.title = "Fargo"
        item23.genre = "Crime, Drama, Thriller"
        item23.day = ["Wednesday"]
        
        let item24 = TVshows()
        item24.title = "This Is Us"
        item24.genre = "Comedy, Drama"
        item24.day = ["Tuesday"]
        
        let item25 = TVshows()
        item25.title = "Taboo"
        item25.genre = "Drama"
        item25.day = ["Saturday"]
        
        let item26 = TVshows()
        item26.title = "Suits"
        item26.genre = "Comedy, Drama"
        item26.day = ["Wednesday"]
        
        let item27 = TVshows()
        item27.title = "The Walking Dead"
        item27.genre = "Drama, Horror, Thriller"
        item27.day = ["Sunday"]
        
        let item28 = TVshows()
        item28.title = "Modern Family"
        item28.genre = "Comedy, Romance"
        item28.day = ["Wednesday"]
        
        let item29 = TVshows()
        item29.title = "Bob's Burgers"
        item29.genre = "Animation, Comedy"
        item29.day = ["Sunday"]
        
        let item30 = TVshows()
        item30.title = "Homeland"
        item30.genre = "Crime, Drama, Mystery"
        item30.day = ["Sunday"]
        
        let item31 = TVshows()
        item31.title = "SpongeBob SquarePants"
        item31.genre = "Animation, Comedy, Family"
        item31.day = ["Saturday"]
        
        let item32 = TVshows()
        item32.title = "Better Call Saul"
        item32.genre = "Crime, Drama"
        item32.day = ["Monday"]
        
        let item33 = TVshows()
        item33.title = "Lucifer"
        item33.genre = "Crime, Drama, Fantasy"
        item33.day = ["Monday"]
        
        
        
        recommendItem = [item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13, item14, item15, item16, item17, item18, item19, item20, item21, item22, item23, item24, item25, item26, item27, item28, item29, item30, item31, item32, item33]
        // End of Section

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    //  When the phone is shaked
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if event?.subtype == UIEventSubtype.motionShake
        {
            if favoriteList.count != 0
            {
                input = recommend(list: recommendItem)
                if input != "Nothing found"
                {
                    self.performSegue(withIdentifier: "toShow", sender: self)
                }
                else
                {
                    let alert = UIAlertController(title: "Opps!", message: "Please add more TV shows to your favorite list.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }
            else
            {
                var newRecList = [TVshows]()
                for x in recommendItem
                {
                    if (Set(x.day)).isSubset(of: dateList)
                    {
                        newRecList.append(x)
                    }
                }
                let index = Int(arc4random_uniform(UInt32(newRecList.count)))
                input = newRecList[index].title
                self.performSegue(withIdentifier: "toShow", sender: self)
            }
        }
    }
    
    
    var input = ""

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toShow" {
            
            let destinationVC = segue.destination as! NextViewController
            destinationVC.input = input
            
        }
        
    }
    
    //  function to generate a recommended TV show to the user based on his or her time availability and interests.
    
    
    
    func recommend(list: [TVshows]) -> String
    {
        var newRecList = [TVshows]()
        
        //  find TV shows suit user's time availability
        for x in list
        {
           if (Set(x.day)).isSubset(of: dateList)
           {
            newRecList.append(x)
            }
        }
        
        //  make a copy of the list
        let copyList = newRecList
        
        var gList = [String] ()
        for x in favoriteList
        {
            let generList = x.genre.components(separatedBy: ", ")
            gList.append(contentsOf: generList)
        }
        let genSet = Set(gList)
        let genList = Array(genSet)
        var count = [Int]()
        
        for x in genSet
        {
            let countNum = gList.filter { $0 == x }.count
    
            count.append(countNum)
            //  counting each genre
            
        }

        let sortedx = zip(genList, count).sorted { $0.1 > $1.1 }
        
        let sortedList = sortedx.map { $0.0 }
        
        let resultSet = Set(sortedList)
        

        
        //  Section of computing recommendations
        //  **********************************
        
        var xList = [String]()
        var yList = [Int]()
        for x in newRecList
        {
            if resultSet.intersection(x.genre.components(separatedBy: ", ")).count > 0
            {
                xList.append(x.title)
                yList.append(resultSet.intersection(x.genre.components(separatedBy: ", ")).count)
            }
        }
        if xList.count>1
        {
        let sortedxy = zip(xList, yList).sorted { $0.1 > $1.1 }
        xList = sortedxy.map { $0.0 }
        yList = sortedxy.map { $0.1 }
        }
        
        print("**********************")
        for (x,y) in zip(xList, yList)
        {
            print ("Show \(x) has \(y) intersections")
        }
        
        var favListTitle = [String]()
        for x in favoriteList
        {
            favListTitle.append(x.title)
        }
        
        var firstList = [String]()
        var secondList = [String]()
        var lastList = [String]()
        
        for (x,y) in zip(xList, yList)
        {
            if y == 3
            {
                firstList.append(x)
            }
            if y == 2
            {
                secondList.append(x)
            }
            if y == 1
            {
                lastList.append(x)
            }
        }
        
        while (!firstList.isEmpty)
        {
            for x in favListTitle
            {
                firstList = firstList.filter { $0 != x }
            }
            let index = Int(arc4random_uniform(UInt32(firstList.count)))
            print ("count \(firstList.count)")
            if firstList.isEmpty
            {
                break
            }
            print("1")
            return firstList[index]
        }
        while (!secondList.isEmpty)
        {
            for x in favListTitle
            {
                secondList = secondList.filter { $0 != x }
            }
            let index = Int(arc4random_uniform(UInt32(secondList.count)))
            if secondList.isEmpty
            {
                break
            }
            print("2")
            return secondList[index]
            
        }
        while (!lastList.isEmpty)
        {
            for x in favListTitle
            {
                lastList = lastList.filter { $0 != x }
            }
            let index = Int(arc4random_uniform(UInt32(lastList.count)))
            if lastList.isEmpty
            {
                break
            }
            print("3")
            return lastList[index]
        }
        
        //  if there is no show recommended based on the user's interests
        
        let index = Int(arc4random_uniform(UInt32(copyList.count)))
        print("copylist")
        return copyList[index].title
    }

}
