//
//  InitViewController.swift
//  TVshows
//
//  Created by DanielT on 5/3/17.
//  Copyright © 2017 Zhewen Tang. All rights reserved.
//

// View controller of the initial page that ask users for date input

var dateList = [String]()

import UIKit

class InitViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //  add corresponding day to the dateList
    
    @IBAction func monday(_ sender: UIButton) {
        dateList.append("Monday")
    }
    
    @IBAction func tu(_ sender: UIButton) {
        dateList.append("Tuesday")
    }
    
    @IBAction func wed(_ sender: UIButton) {
        dateList.append("Wednesday")
    }
    
    @IBAction func thur(_ sender: UIButton) {
        dateList.append("Thursday")
    }

    @IBAction func fri(_ sender: UIButton) {
        dateList.append("Friday")
    }
    
    @IBAction func Sat(_ sender: UIButton) {
        dateList.append("Saturday")
    }
    
    @IBAction func sun(_ sender: UIButton) {
        dateList.append("Sunday")
    }
    
    @IBAction func go(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToMain", sender: self)
        dateList = Array(Set(dateList))
    }
    
    //  if skip, add all seven days to the dateList
    
    @IBAction func skip(_ sender: UIButton) {
        dateList = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        dateList = Array(Set(dateList))
        self.performSegue(withIdentifier: "goToMain", sender: self)
        
    }
    
}
