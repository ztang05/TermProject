//
//  FavoriteTableViewCell.swift
//  TVshows
//
//  Created by DanielT on 2017/3/27.
//  Copyright © 2017年 Zhewen Tang. All rights reserved.
//

import UIKit

class FavoriteTableViewCell: UITableViewCell {

    
    @IBOutlet weak var epImage: UIImageView!
    @IBOutlet weak var showDes: UILabel!
    @IBOutlet weak var nextDate: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var star: UIImageView!
    @IBOutlet weak var showsTitle: UILabel!
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
